<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\ComponentsType;
use App\Models\Component;
use App\Models\Vyrobce;
use App\Models\Parametr;
class Main extends BaseController
{
    var $typC;
    var $com;
    var $vyrobce;
    var $parametr;
    public function __construct(){
        $this->typC = new ComponentsType();
        $this->com = new Component();
        $this->vyrobce = new Vyrobce();
        $this->parametr = new Parametr();
    }
    
    public function index()
    {   
    }
    public function getType()
    {
        $data["typC"] = $this->typC->findall();
        echo view("componetsType", $data);
    }
    public function getKomponent($id)
    {
        
        $data["com"] = $this->com->where('typKomponentid',$id)->paginate(5);
        $data["pager"] = $this->com->pager;
        echo view("components", $data);
    }
    public function getInfo($id)
    {
        $data["com"] = $this->com->join('vyrobce', 'komponent.vyrobce_id = vyrobce.idVyrobce',"inner")->join('parametr', 'komponent.id = parametr.komponent_id',"inner")->join('nazevparametr', 'nazevparametr.id = parametr.nazevParametr_id',"inner")->find($id); 
        $data["parametr"] = $this->parametr->join('nazevparametr', 'nazevparametr.id = parametr.nazevParametr_id',"inner")->where("komponent_id", $id)->findall();
        echo view("compInfo", $data);
    }
    /**public function getUdaje($id2)
    {
        $data["stanice"] = $this->zeme->find($id2);
        $data["udaje"] = $this->udaje->where('Stations_ID',$id2)->findall();
        echo view("udaje-stanice", $data);
    }
    public function getBundesland($id3)
    {
        $data["zeme"] = $this->zeme->find($id3);
        $data["stanice"] = $this->stanice->where('bundesland',$id3)->findall();
        echo view("bundesland", $data);
    }
    public function getPrehledStanic()
    {
        $data["zeme"] = $this->zeme->join('station', 'bundesland.id = station.bundesland',"inner")->findall();//joinuju tabulky
        echo view("prehled-stanice", $data);
    }*/
}