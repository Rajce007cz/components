<link rel="stylesheet" href="<?=base_url('assets/bootstrap/css/bootstrap.css');?>">
<script src="<?=base_url('assets/bootstrap/js/bootstrap.bundle.js')?>"></script>